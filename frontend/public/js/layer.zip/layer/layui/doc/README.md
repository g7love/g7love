注意事项：
1、页面的HTML代码必须是 <!DOCTYPE html> 开头
2、除ie6、7外，所有浏览器均支持